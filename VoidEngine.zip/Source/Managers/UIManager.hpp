//
// Created by Hrefna on 8.10.2024.
//

#pragma once

namespace VoidEngine {

class UIManager {

};

} // VoidEngine